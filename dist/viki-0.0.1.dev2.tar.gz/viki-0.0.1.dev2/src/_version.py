# -*- coding: utf-8 -*-  

"""
_version.py
~~~~~~~~~~~

Provides Viki version information.
:license: Apache2, see LICENSE for more details. 
"""

__version__ = "0.0.1.dev2"

__all__ = ["__version__"]